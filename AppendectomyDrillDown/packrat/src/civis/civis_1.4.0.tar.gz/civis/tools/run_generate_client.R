source("R/generate_client.R")
source("R/client_base.R")
source("R/utils.R")

fetch_and_generate_client()

