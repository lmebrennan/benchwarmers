library(testthat)
library(civis)

test_check("civis")
